# STGT: An Intra-Stream Evolution Feature Extraction Method for Event Camera Action Recognition


如何构建图形转换器？我们提供了一个关于如何构建具有线性复杂性的图形转换器的三部分配方。我们的GPS配方包括选择3种主要成分：
1. 位置/结构编码: [LapPE](https://arxiv.org/abs/2106.03893)
2. 本地消息传递机制: [GatedGCN](https://arxiv.org/abs/1711.07553)
3. 全局关注机制: [Transformer](https://arxiv.org/abs/1706.03762)

使用[PyG]构建的(https://www.pyg.org/)和[来自PyG2的GraphGym](https://pytorch-geometric.readthedocs.io/en/2.0.0/notes/graphgym.html).


### Python environment setup with Conda

```bash
conda create -n graphgps python=3.10
conda activate graphgps

conda install pytorch=1.13 torchvision torchaudio pytorch-cuda=11.7 -c pytorch -c nvidia
conda install pyg=2.2 -c pyg -c conda-forge
pip install pyg-lib -f https://data.pyg.org/whl/torch-1.13.0+cu117.html

# RDKit is required for OGB-LSC PCQM4Mv2 and datasets derived from it.  
conda install openbabel fsspec rdkit -c conda-forge

pip install pytorch-lightning yacs torchmetrics
pip install performer-pytorch
pip install tensorboardX
pip install ogb
pip install wandb

conda clean --all
```


### Running GraphGPS
```bash
conda activate graphgps

python main.py --cfg configs/GPS/THU-EACT-50.yaml  wandb.use False

```
