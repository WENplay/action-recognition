import datetime
import os
import torch
import logging

# import graphgps  # noqa, register custom modules
from graphgps.agg_runs import agg_runs
from graphgps.optimizer.extra_optimizers import ExtendedSchedulerConfig

from torch_geometric.graphgym.cmd_args import parse_args
from torch_geometric.graphgym.config import (cfg, dump_cfg, set_cfg, load_cfg, makedirs_rm_exist)
from torch_geometric.graphgym.loader import create_loader
from torch_geometric.graphgym.logger import set_printing
from torch_geometric.graphgym.optim import create_optimizer, create_scheduler, OptimizerConfig
from torch_geometric.graphgym.model_builder import create_model
from torch_geometric.graphgym.train import GraphGymDataModule, train
from torch_geometric.graphgym.utils.comp_budget import params_count
from torch_geometric.graphgym.utils.device import auto_select_device
from torch_geometric.graphgym.register import train_dict
from torch_geometric import seed_everything

from graphgps.finetuning import load_pretrained_model_cfg, init_model_from_pretrained
from graphgps.logger import create_logger


torch.backends.cuda.matmul.allow_tf32 = True  # Default False in PyTorch 1.12+
torch.backends.cudnn.allow_tf32 = True  # Default True


def new_optimizer_config(cfg):
    return OptimizerConfig(optimizer=cfg.optim.optimizer, base_lr=cfg.optim.base_lr,
                           weight_decay=cfg.optim.weight_decay, momentum=cfg.optim.momentum)


def new_scheduler_config(cfg):
    return ExtendedSchedulerConfig(scheduler=cfg.optim.scheduler, steps=cfg.optim.steps, lr_decay=cfg.optim.lr_decay,  # 
        max_epoch=cfg.optim.max_epoch, reduce_factor=cfg.optim.reduce_factor, schedule_patience=cfg.optim.schedule_patience, min_lr=cfg.optim.min_lr,
        num_warmup_epochs=cfg.optim.num_warmup_epochs, train_mode=cfg.train.mode, eval_period=cfg.train.eval_period)


def custom_set_out_dir(cfg, cfg_fname, name_tag):
    """将自定义main输出目录路径设置为cfg.
    在新的：obj:`cfg.out_dir`中包括配置文件名和名称标记。

    Args:
        cfg (CfgNode): 配置节点
        cfg_fname (string): yaml格式配置文件的加载路径
        name_tag (string): 用于标识此配置文件执行的附加名称标记，在：obj:`cfg.name_tag中指定`=''
    """
    run_name = os.path.splitext(os.path.basename(cfg_fname))[0]  # run_name='THU-EACT-50'
    run_name += f"-{name_tag}" if name_tag else ""  # name_tag有值则在前面添加，否则不添加
    cfg.out_dir = os.path.join(cfg.out_dir, run_name)  # 输出路径为result/THU-EACT-50/


def custom_set_run_dir(cfg, run_id, n):
    """每个实验运行的自定义输出目录命名。

    Args:
        cfg (CfgNode): 配置节点
        run_id (int): Main for-loop iter id (随机种子或数据集拆分)
    """
    cfg.run_dir = os.path.join(cfg.out_dir, 'output', n)  # 设置运行路径
    # 生成输出目录
    if cfg.train.auto_resume:  # False
        os.makedirs(cfg.run_dir, exist_ok=True)  # 生成目录，如果已存在不会引发错误
    else:
        makedirs_rm_exist(cfg.run_dir)  # （删除目录）新建目录


def run_loop_settings():
    """基于当前cfg创建主循环执行设置。

    将主执行循环配置为以两种模式之一运行：
    1. 'multi-seed' - 当args.repeats控制实验运行的重复次数时，再现GraphGym的默认行为。
        每次迭代都使用一个随机种子执行，该种子设置为从初始cfg.seed开始的上一次迭代的增量。
    2. 'multi-split' - 在多个数据集分割上执行实验运行，这些分割可以是多个CV分割或多个标准分割。 
        对于每个运行迭代，随机种子将重置为初始cfg.seed值。

    Returns:
        每个循环迭代的运行ID列表
        要循环的rng种子列表
        要循环的数据集拆分索引列表
    """
    if len(cfg.run_multiple_splits) == 0:
        # 'multi-seed' run mode
        num_iterations = args.repeat
        seeds = [cfg.seed + x for x in range(num_iterations)]  # 创建一个种子列表，每个种子从cfg.seed开始并加上一个递增的数字（从0到num_iterations-1）
        split_indices = [cfg.dataset.split_index] * num_iterations  # 创建分割索引列表
        run_ids = seeds
    else:
        # 'multi-split' run mode
        if args.repeat != 1:
            raise NotImplementedError("运行多次的多次重复，不支持在一次运行中进行拆分。")
        num_iterations = len(cfg.run_multiple_splits)
        seeds = [cfg.seed] * num_iterations
        split_indices = cfg.run_multiple_splits
        run_ids = split_indices
    return run_ids, seeds, split_indices  # 返回（种子列表/分割索引列表），种子列表，分割索引列表


if __name__ == '__main__':
    n='v=3,d=7,n=512'
    args = parse_args()
    # 加载配置文件
    set_cfg(cfg)
    load_cfg(cfg, args)
    custom_set_out_dir(cfg, args.cfg_file, cfg.name_tag)  # 结果为result/THU-EACT-50/,args.cfg_file='/home/user/code/GraphGPS-C/configs/GPS/THU-EACT-50.yaml',cfg.name_tag=''
    dump_cfg(cfg)  # 创建目录并写入配置文件
    # 设置Pytorch环境
    torch.set_num_threads(cfg.num_threads)  # 为pytorch进程设置线程数
    # 重复多次实验运行
    for run_id, seed, split_index in zip(*run_loop_settings()):  # 将run_loop_settings返回的元素打包，并分别赋值给三个变量，第一次三个值全为0
        # 设置每次运行的配置
        custom_set_run_dir(cfg, run_id, n)  # 设置输出目录
        set_printing()  # 设置输出日志
        cfg.dataset.split_index = split_index # 设置cfg中的三个值
        cfg.seed = seed
        cfg.run_id = run_id
        seed_everything(cfg.seed)  # 随机种子的设置
        cfg.accelerator='cuda:0'  # 选择GPU-1或者CPU-0
        if cfg.pretrained.dir:
            cfg = load_pretrained_model_cfg(cfg)  # 加载预训练模型的cfg
        logging.info(f"[*] Run ID {run_id}: seed={cfg.seed}, " f"split_index={cfg.dataset.split_index}")
        logging.info(f"Starting now: {datetime.datetime.now()}")  # 获取当前的时间和日期
        # 设置机器学习流程
        loaders = create_loader()
        loggers = create_logger()  # 创建空的train、val、test的loggers
        model = create_model()
        if cfg.pretrained.dir:  # 缺失
            model = init_model_from_pretrained(model, cfg.pretrained.dir, cfg.pretrained.freeze_main,
                cfg.pretrained.reset_prediction_head, seed=cfg.seed)
        optimizer = create_optimizer(model.parameters(), new_optimizer_config(cfg))
        scheduler = create_scheduler(optimizer, new_scheduler_config(cfg))
        
        # Print model info
        logging.info(model)  # 打印模型
        # logging.info(cfg)  # 打印cfg
        
        cfg.params = params_count(model)  # 计算模型的参数
        logging.info('Num parameters: %s', cfg.params)  # 打印
        # Start training
        if cfg.train.mode == 'standard':  # cfg.train.mode=custom
            if cfg.wandb.use:
                logging.warning("[W] WandB logging is not supported with the " "default train.mode, set it to `custom`")
            datamodule = GraphGymDataModule()
            train(model, loaders, logger=True)
        else:
            train_dict[cfg.train.mode](loggers, loaders, model, optimizer, scheduler)
    # 不同种子的聚合结果
    try:
        agg_runs(cfg.out_dir, cfg.metric_best)
    except Exception as e:
        logging.info(f"Failed when trying to aggregate multiple runs: {e}")
    # 在批处理模式下启动时，将yaml标记为完成
    if args.mark_done:
        os.rename(args.cfg_file, f'{args.cfg_file}_done')
    logging.info(f"[*] All done: {datetime.datetime.now()}")
