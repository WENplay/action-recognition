import logging
import time
import torch.nn.functional as F
import numpy as np
import torch
from scipy.stats import stats
from sklearn.metrics import accuracy_score, precision_score, recall_score, \
    f1_score, roc_auc_score, mean_absolute_error, mean_squared_error, confusion_matrix
from sklearn.metrics import r2_score
from torch_geometric.graphgym import get_current_gpu_usage
from torch_geometric.graphgym.config import cfg
from torch_geometric.graphgym.logger import infer_task, Logger
from torch_geometric.graphgym.utils.io import dict_to_json, dict_to_tb
from torchmetrics.functional import auroc


def top5acc(pred,true):
    # 将预测得分转为降序排列后的类别索引
    _, pred_label_top5 = pred.topk(k=5, dim=1, largest=True, sorted=True)

    # 检查每个样本的top5预测类别中是否包含其真实类别
    correct_top5 = (true.unsqueeze(1) == pred_label_top5).any(dim=1)

    # 计算top-5准确率
    top5_accuracy = correct_top5.float().mean().item()
    return top5_accuracy

def top1acc(pred,true):
    # 获取每个样本预测得分最高的类别索引
    pred_top1 = pred.argmax(dim=1)

    # 计算预测的top-1标签与真实标签的匹配情况
    correct_predictions = (pred_top1 == true).float().sum()

    # 计算总的样本数量
    total_samples = true.numel()

    # 计算并输出top-1准确率
    top1_accurary = correct_predictions.item() / total_samples
    return top1_accurary

def top3acc(pred,true):
        # 将预测标签转为一维（按行最大值排序后的索引）
    _, pred_top_k_indices = pred.topk(k=3, dim=1, largest=True, sorted=True)

    # 创建一个（6599, k）的布尔张量，记录每个样本的前k个预测类别中是否包含真实类别
    contains_true_label = (true.unsqueeze(1) == pred_top_k_indices).any(dim=1)

    # 计算top-3准确率
    top3_accuracy = contains_true_label.float().mean().item()

    return top3_accuracy

def accuracy_SBM(targets, pred_int):
    """Accuracy eval for Benchmarking GNN's PATTERN and CLUSTER datasets.
    https://github.com/graphdeeplearning/benchmarking-gnns/blob/master/train/metrics.py#L34
    """
    S = targets
    C = pred_int
    CM = confusion_matrix(S, C).astype(np.float32)
    nb_classes = CM.shape[0]
    targets = targets.cpu().detach().numpy()
    nb_non_empty_classes = 0
    pr_classes = np.zeros(nb_classes)
    for r in range(nb_classes):
        cluster = np.where(targets == r)[0]
        if cluster.shape[0] != 0:
            pr_classes[r] = CM[r, r] / float(cluster.shape[0])
            if CM[r, r] > 0:
                nb_non_empty_classes += 1
        else:
            pr_classes[r] = 0.0
    acc = np.sum(pr_classes) / float(nb_classes)
    return acc


class CustomLogger(Logger):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # 是否运行替代分数实现的比较测试。
        self.test_scores = False

    # basic properties
    def basic(self):
        stats = {'loss': round(self._loss / self._size_current, max(8, cfg.round)),
            'lr': round(self._lr, max(8, cfg.round)), 'params': self._params,
            }  # 'time_iter': round(self.time_iter(), cfg.round),
        gpu_memory = get_current_gpu_usage()
        if gpu_memory > 0:
            stats['gpu_memory'] = gpu_memory
        return stats

    # task properties
    def classification_binary(self):
        true = torch.cat(self._true).squeeze(-1)
        pred_score = torch.cat(self._pred)
        pred_int = self._get_pred_int(pred_score)

        if true.shape[0] < 1e7:  # AUROC computation for very large datasets is too slow.
            # TorchMetrics AUROC on GPU if available.
            # 在计算auroc_score之前，将目标标签转换为one-hot编码
            true_one_hot = F.one_hot(true, num_classes=cfg.share.dim_out)

            # 修改为使用one-hot编码的目标标签计算AUROC
            auroc_score = auroc(pred_score.to(torch.device(cfg.accelerator)),
                                true_one_hot.to(torch.device(cfg.accelerator)), task='binary')
            if self.test_scores:
                # SK-learn version.
                try:
                    r_a_score = roc_auc_score(true.cpu().numpy(), pred_score.cpu().numpy())
                except ValueError:
                    r_a_score = 0.0
                assert np.isclose(float(auroc_score), r_a_score)
        else:
            auroc_score = 0.

        reformat = lambda x: round(float(x), cfg.round)
        res = {'accuracy': reformat(accuracy_score(true, pred_int)),  # 其中有top准确率的计算，可以使用
            }  #'precision': reformat(precision_score(true, pred_int)),
            # 'recall': reformat(recall_score(true, pred_int)),
            # 'f1': reformat(f1_score(true, pred_int)), 'auc': reformat(auroc_score),
        if cfg.metric_best == 'accuracy-SBM':
            res['accuracy-SBM'] = reformat(accuracy_SBM(true, pred_int))
        return res

    def classification_multi(self):
        true, pred_score = torch.cat(self._true), torch.cat(self._pred)
        pred_int = self._get_pred_int(pred_score)
        reformat = lambda x: round(float(x), cfg.round)

        res = {'accuracy': reformat(accuracy_score(true, pred_int)), 'top-1':reformat(top1acc(pred_score,true)), 'top-3':reformat(top3acc(pred_score,true)), 'top-5':reformat(top5acc(pred_score,true)), 
            'f1': reformat(f1_score(true, pred_int, average='macro', zero_division=0)),}
        if cfg.metric_best == 'accuracy-SBM':
            res['accuracy-SBM'] = reformat(accuracy_SBM(true, pred_int))
        if true.shape[0] < 1e7:
            # AUROC computation for very large datasets runs out of memory.
            # TorchMetrics AUROC on GPU is much faster than sklearn for large ds
            res['auc'] = reformat(auroc(pred_score.to(torch.device(cfg.accelerator)),
                                        true.to(torch.device(cfg.accelerator)).squeeze(),
                                        task='multiclass',
                                        num_classes=pred_score.shape[1],
                                        average='macro'))

            if self.test_scores:
                # SK-learn version.
                sk_auc = reformat(roc_auc_score(true, pred_score.exp(),
                                                average='macro',
                                                multi_class='ovr'))
                assert np.isclose(sk_auc, res['auc'])

        return res
    
    def regression(self):
        true, pred = torch.cat(self._true), torch.cat(self._pred)
        reformat = lambda x: round(float(x), cfg.round)
        return {
            'mae': reformat(mean_absolute_error(true, pred)),
            'r2': reformat(r2_score(true, pred, multioutput='uniform_average')),
            'spearmanr': reformat(eval_spearmanr(true.numpy(), pred.numpy())['spearmanr']),
            'mse': reformat(mean_squared_error(true, pred)),
            'rmse': reformat(mean_squared_error(true, pred, squared=False)),
        }

    def update_stats(self, true, pred, loss, lr, time_used, params, dataset_name=None, **kwargs):
        if dataset_name == 'THUEACT50':
            assert true.shape[0] == pred.shape[0]
            batch_size = true.shape[0]
        self._iter += 1
        self._true.append(true)
        self._pred.append(pred)
        self._size_current += batch_size
        self._loss += loss * batch_size
        self._lr = lr
        self._params = params
        self._time_used += time_used
        self._time_total += time_used
        for key, val in kwargs.items():
            if key not in self._custom_stats:
                self._custom_stats[key] = val * batch_size
            else:
                self._custom_stats[key] += val * batch_size

    def write_epoch(self, cur_epoch):
        start_time = time.perf_counter()
        basic_stats = self.basic()

        if self.task_type == 'regression':
            task_stats = self.regression()
        elif self.task_type == 'classification_binary':  # True
            task_stats = self.classification_binary()
        elif self.task_type == 'classification_multi':
            task_stats = self.classification_multi()
        elif self.task_type == 'classification_multilabel':
            task_stats = self.classification_multilabel()
        elif self.task_type == 'subtoken_prediction':
            task_stats = self.subtoken_prediction()
        else:
            raise ValueError('Task has to be regression or classification')

        epoch_stats = {'epoch': cur_epoch, 'time_epoch': round(self._time_used, cfg.round)}
        eta_stats = {'eta': round(self.eta(cur_epoch), cfg.round), 'eta_hours': round(self.eta(cur_epoch) / 3600, cfg.round)}
        custom_stats = self.custom()

        if self.name == 'train':
            stats = {
                **epoch_stats,  # include(epoch回合数,time_epoch回合时间)
               # **eta_stats,   include(eta正确回合使用时间,eta_hours确切到小时)
                **basic_stats,  # include(loss损失,lr学习率,params参数量,time_iter迭代时间=time_epoch/_iter)
                **task_stats,  # include(accuracy准确率，正确样本数/总样本数,precision精度:直观地说明分类器不将样本标记为阳性的能力,这是负面的。最佳值为1，最差值为0,
                # recall召回率，直观地说明分类器查找所有阳性样本的能力。最佳值为1，最差值为0。,f1，F1分数，1最好0最差，使用precision和recall计算得出，auc,AUROC得分)
               # **custom_stats
            }
        else:
            stats = {
                **epoch_stats,
                **basic_stats,
                **task_stats,
                # **custom_stats
            }

        # print
        logging.info('{}: {}'.format(self.name, stats))
        # json
        dict_to_json(stats, '{}/stats.json'.format(self.out_dir))
        # tensorboard
        if cfg.tensorboard_each_run:
            dict_to_tb(stats, self.tb_writer, cur_epoch)
        self.reset()
        if cur_epoch < 3:
            logging.info(f"...computing epoch stats took: " f"{time.perf_counter() - start_time:.2f}s")
        return stats


def create_logger():
    """
    为实验创建记录器

    Returns: 记录器对象列表

    """
    loggers = []
    names = ['train', 'val', 'test']
    for i, dataset in enumerate(range(cfg.share.num_splits)):   # i为索引       
        loggers.append(CustomLogger(name=names[i], task_type=infer_task()))
        # 为每个分割创建一个新的CustomLogger对象，并将这些对象添加到loggers列表中。
    return loggers


def eval_spearmanr(y_true, y_pred):
    """Compute Spearman Rho averaged across tasks.
    """
    res_list = []

    if y_true.ndim == 1:
        res_list.append(stats.spearmanr(y_true, y_pred)[0])
    else:
        for i in range(y_true.shape[1]):
            # ignore nan values
            is_labeled = ~np.isnan(y_true[:, i])
            res_list.append(stats.spearmanr(y_true[is_labeled, i],
                                            y_pred[is_labeled, i])[0])

    return {'spearmanr': sum(res_list) / len(res_list)}
