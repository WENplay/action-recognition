# import numpy as np
import torch
import torch.nn as nn
import torch_geometric.graphgym.register as register
import torch_geometric.nn as pygnn
# from performer_pytorch import SelfAttention
from torch_geometric.data import Batch
# from torch_geometric.nn import Linear as Linear_pyg
from torch_geometric.utils import to_dense_batch

# from graphgps.layer.bigbird_layer import SingleBigBirdLayer
from graphgps.layer.gatedgcn_layer import GatedGCNLayer
# from graphgps.layer.gine_conv_layer import GINEConvESLapPE


class GPSLayer(nn.Module):
    """局部MPNN+全图注意力x-former层.
    """

    def __init__(self, dim_h, local_gnn_type, global_model_type, num_heads, act='relu',
                 pna_degrees=None, equivstable_pe=False, dropout=0.0, attn_dropout=0.0, layer_norm=False, batch_norm=True,
                 log_attn_weights=False):
        super().__init__()

        self.dim_h = dim_h  # 52
        self.num_heads = num_heads  # 4
        self.attn_dropout = attn_dropout  # 0.5
        self.layer_norm = layer_norm  # False
        self.batch_norm = batch_norm  # True
        self.equivstable_pe = equivstable_pe  # False
        self.activation = register.act_dict[act] # sct=relu

        self.log_attn_weights = log_attn_weights  # False
        if log_attn_weights and global_model_type not in ['Transformer', 'BiasedTransformer']:  # False global_model_type=Transformer
            raise NotImplementedError(f"Logging of attention weights is not supported " f"for '{global_model_type}' global attention model.")

        # 本地消息传递模型.
        self.local_gnn_with_edge_attr = True
        if local_gnn_type == 'None':  # local_gnn_type='CustomGatedGCN'
            self.local_model = None

        elif local_gnn_type == 'CustomGatedGCN':   # True
            self.local_model = GatedGCNLayer(dim_h, dim_h, dropout=dropout, residual=True,
                                             act=act, equivstable_pe=equivstable_pe)
        else:
            raise ValueError(f"Unsupported local GNN model: {local_gnn_type}")
        self.local_gnn_type = local_gnn_type

        # Global attention transformer-style model.
        if global_model_type == 'None':  # 'Transformer'
            self.self_attn = None
        elif global_model_type in ['Transformer', 'BiasedTransformer']:
            self.self_attn = torch.nn.MultiheadAttention(dim_h, num_heads, dropout=self.attn_dropout, batch_first=True)
        else:
            raise ValueError(f"Unsupported global x-former model: " f"{global_model_type}")
        self.global_model_type = global_model_type  # 'Transformer'

        if self.layer_norm and self.batch_norm:
            raise ValueError("Cannot apply two types of normalization together")

        # MPNN和自注意表示的归一化。
        if self.layer_norm:  # False
            self.norm1_local = pygnn.norm.LayerNorm(dim_h)
            self.norm1_attn = pygnn.norm.LayerNorm(dim_h)
        if self.batch_norm:  # True
            self.norm1_local = nn.BatchNorm1d(dim_h)  # 52
            self.norm1_attn = nn.BatchNorm1d(dim_h)
        self.dropout_local = nn.Dropout(dropout)  # 0.0
        self.dropout_attn = nn.Dropout(dropout)

        # 前馈块.
        self.ff_linear1 = nn.Linear(dim_h, dim_h * 2)  # 52,104
        self.ff_linear2 = nn.Linear(dim_h * 2, dim_h)  # 104,52
        self.act_fn_ff = self.activation()  # ReLU
        if self.layer_norm:  # False
            self.norm2 = pygnn.norm.LayerNorm(dim_h)
            # self.norm2 = pygnn.norm.GraphNorm(dim_h)
            # self.norm2 = pygnn.norm.InstanceNorm(dim_h)
        if self.batch_norm:  # True
            self.norm2 = nn.BatchNorm1d(dim_h)
        self.ff_dropout1 = nn.Dropout(dropout)
        self.ff_dropout2 = nn.Dropout(dropout)

    def forward(self, batch):
        h = batch.x  # 8192*52
        h_in1 = h  # 对于第一个残差连接  8192*52

        h_out_list = []
        # 具有边属性的局部MPNN。
        if self.local_model is not None:  # True
            self.local_model: pygnn.conv.MessagePassing  # Typing hint. GatedGCNLayer
            if self.local_gnn_type == 'CustomGatedGCN':  # True
                es_data = None
                if self.equivstable_pe:  # False
                    es_data = batch.pe_EquivStableLapPE
                local_out = self.local_model(Batch(batch=batch, x=h, edge_index=batch.edge_index,
                                                   edge_attr=batch.edge_attr, pe_EquivStableLapPE=es_data))
                # GatedGCN在内部进行残差连接和断开。
                h_local = local_out.x    # 3072*52  对节点特征进行更新
                batch.edge_attr = local_out.edge_attr  # 实用计算出的结果更新边特征
            else:
                if self.local_gnn_with_edge_attr:  # True
                    if self.equivstable_pe:  # False
                        h_local = self.local_model(h, batch.edge_index, batch.edge_attr, batch.pe_EquivStableLapPE)
                    else:  # run
                        h_local = self.local_model(h, batch.edge_index, batch.edge_attr)
                else:
                    h_local = self.local_model(h, batch.edge_index)
                h_local = self.dropout_local(h_local)
                h_local = h_in1 + h_local  # 残差连接。

            if self.layer_norm:  # False
                h_local = self.norm1_local(h_local, batch.batch)
            if self.batch_norm:  # True
                h_local = self.norm1_local(h_local)  # shape()
            h_out_list.append(h_local)

        # Multi-head attention.
        if self.self_attn is not None:
            h_dense, mask = to_dense_batch(h, batch.batch)
            if self.global_model_type == 'Transformer':  # True
                h_attn = self._sa_block(h_dense, None, ~mask)[mask]
            elif self.global_model_type == 'BiasedTransformer':
                # Use Graphormer-like conditioning, requires `batch.attn_bias`.
                h_attn = self._sa_block(h_dense, batch.attn_bias, ~mask)[mask]
            elif self.global_model_type == 'Performer':
                h_attn = self.self_attn(h_dense, mask=mask)[mask]
            else:
                raise RuntimeError(f"Unexpected {self.global_model_type}")

            h_attn = self.dropout_attn(h_attn)
            h_attn = h_in1 + h_attn  # 残差连接.  8192*52
            if self.layer_norm:  # False
                h_attn = self.norm1_attn(h_attn, batch.batch)
            if self.batch_norm:  # True
                h_attn = self.norm1_attn(h_attn)  # shape()
            h_out_list.append(h_attn) 

        # 结合局部和全局输出。
        # h = torch.cat(h_out_list, dim=-1)
        h = sum(h_out_list)  # 8192*52

        # 前馈模块.
        h = h + self._ff_block(h)
        if self.layer_norm:  # False
            h = self.norm2(h, batch.batch)
        if self.batch_norm:  # True
            h = self.norm2(h)

        batch.x = h
        return batch

    def _sa_block(self, x, attn_mask, key_padding_mask):
        """自注意力模块
        """
        if not self.log_attn_weights:  # False
            x = self.self_attn(x, x, x, attn_mask=attn_mask,
                               key_padding_mask=key_padding_mask, need_weights=False)[0]
        else:
            # 需要PyTorch v1.11+支持`average_attn_weights=False`
            # 返回单个头部的注意力权重的选项。
            # self.self_attn = torch.nn.MultiheadAttention(dim_h, num_heads, dropout=self.attn_dropout, batch_first=True)
            x, A = self.self_attn(x, x, x, attn_mask=attn_mask, key_padding_mask=key_padding_mask,
                                  need_weights=True, average_attn_weights=False)  # self-attention,x,x,x代表Q,K,V,输出x为结果，A为对应权重分布
            self.attn_weights = A.detach().cpu()  # 将A分离并转移到CPU
        return x  # shape(16,512,52)

    def _ff_block(self, x):
        """前馈模块。
        """
        x = self.ff_dropout1(self.act_fn_ff(self.ff_linear1(x)))
        return self.ff_dropout2(self.ff_linear2(x))

    def extra_repr(self):
        s = f'summary: dim_h={self.dim_h}, ' \
            f'local_gnn_type={self.local_gnn_type}, ' \
            f'global_model_type={self.global_model_type}, ' \
            f'heads={self.num_heads}'
        return s  # 'summary: dim_h=52, local_gnn_type=CustomGatedGCN, global_model_type=Transformer, heads=4'
