import logging

import torch
from torch_geometric.utils import subgraph
from tqdm import tqdm


def pre_transform_in_memory(dataset, transform_func, show_progress=False):
    """Pre-transform 已加载PyG数据集对象.

    将变换函数应用于加载的PyG数据集对象，以便变换的结果在对象的使用寿命内保持不变。
    这意味着结果不会像PyG的“pre_transform”那样保存到磁盘，而且变换只应用一次，而不是像PyG的“变换”hook那样在每次数据访问时应用。

    Implementation is based on torch_geometric.data.in_memory_dataset.copy

    Args:
        dataset: 要修改的PyG数据集对象
        transform_func: 应用于每个数据示例的转换函数
        show_progress: 显示tqdm进度条
    """
    if transform_func is None:
        return dataset
    
    # 从dataset中获取第i个数据，并显示进度条
    data_list = [transform_func(dataset.get(i)) for i in tqdm(range(len(dataset)), disable=not show_progress, mininterval=10)]
    data_list = list(filter(None, data_list))  # 如果元素为真则保留

    dataset._indices = None
    dataset._data_list = data_list
    dataset.data, dataset.slices = dataset.collate(data_list)


def typecast_x(data, type_str):
    if type_str == 'float':
        data.x = data.x.float()
    elif type_str == 'long':
        data.x = data.x.long()
    else:
        raise ValueError(f"Unexpected type '{type_str}'.")
    return data


def concat_x_and_pos(data):
    data.x = torch.cat((data.x, data.pos), 1)
    return data


def clip_graphs_to_size(data, size_limit=5000):
    if hasattr(data, 'num_nodes'):
        N = data.num_nodes  # Explicitly given number of nodes, e.g. ogbg-ppa
    else:
        N = data.x.shape[0]  # Number of nodes, including disconnected nodes.
    if N <= size_limit:
        return data
    else:
        logging.info(f'  ...clip to {size_limit} a graph of size: {N}')
        if hasattr(data, 'edge_attr'):
            edge_attr = data.edge_attr
        else:
            edge_attr = None
        edge_index, edge_attr = subgraph(list(range(size_limit)),
                                         data.edge_index, edge_attr)
        if hasattr(data, 'x'):
            data.x = data.x[:size_limit]
            data.num_nodes = size_limit
        else:
            data.num_nodes = size_limit
        if hasattr(data, 'node_is_attributed'):  # for ogbg-code2 dataset
            data.node_is_attributed = data.node_is_attributed[:size_limit]
            data.node_dfs_order = data.node_dfs_order[:size_limit]
            data.node_depth = data.node_depth[:size_limit]
        data.edge_index = edge_index
        if hasattr(data, 'edge_attr'):
            data.edge_attr = edge_attr
        return data
