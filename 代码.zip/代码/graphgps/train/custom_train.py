import logging
import time

import numpy as np
import torch
from torch_geometric.graphgym.checkpoint import load_ckpt, save_ckpt, clean_ckpt
from torch_geometric.graphgym.config import cfg
from torch_geometric.graphgym.loss import compute_loss
from torch_geometric.graphgym.register import register_train
from torch_geometric.graphgym.utils.epoch import is_eval_epoch, is_ckpt_epoch

# from graphgps.loss.subtoken_prediction_loss import subtoken_cross_entropy
from graphgps.utils import cfg_to_dict, flatten_dict, make_wandb_name

# logger: 日志记录器，用于收集训练过程中的统计数据。loader: 数据加载器，提供训练批次数据。model: 待训练的深度学习模型。
# optimizer: 优化器，如SGD、Adam等，用于更新模型参数。scheduler: 学习率调度器，控制训练过程中学习率的变化。batch_accumulation: 梯度累积步数，即每隔多少个批次才更新一次权重
def train_epoch(logger, loader, model, optimizer, scheduler, batch_accumulation):  # batch_accumulation=1，训练单个epoch的函数
    model.train()  # 设置为训练模式，启动批量归一化和dropout
    optimizer.zero_grad()  # 梯度清零
    time_start = time.time()  # 记录当前时间
    for iter, batch in enumerate(loader):  # 遍历每个批次的数据，iter为当前批次索引
        batch.split = 'train'  # 数据标签设定为train
        batch.to(torch.device(cfg.accelerator))  # to.cuda
        pred, true = model(batch)  # 前向传播，得到预测值和真实标签
        a=batch.lab
        if cfg.dataset.name == 'THUEACT50':  # 数据集名称
            # print(pred,true)
            loss, pred_score = compute_loss(pred, true)  # pred_score.shape(16*2)  计算损失和预测得分
            _true = true.detach().to('cpu', non_blocking=True)  # shape(16) 分离真实标签记录日志
            _pred = pred_score.detach().to('cpu', non_blocking=True) # 分离预测得分记录日志
        loss.backward()  # 反向传播计算各种参数的梯度
        # 累积给定num. batches梯度后更新参数 .
        if ((iter + 1) % batch_accumulation == 0) or (iter + 1 == len(loader)):  # 达到累计步数或下一个批次则执行以下操作
            if cfg.optim.clip_grad_norm:  # True
                torch.nn.utils.clip_grad_norm_(model.parameters(), cfg.optim.clip_grad_norm_value)  # 执行梯度裁切防止梯度爆炸
            optimizer.step()  # 优化器更新模型参数
            optimizer.zero_grad()  # 梯度清零
            # 更新日志记录器中的统计信息，包括真实标签、预测结果、损失值、当前学习率、时间消耗、训练参数和数据集名
        logger.update_stats(true=_true, pred=_pred, loss=loss.detach().cpu().item(),
                            lr=scheduler.get_last_lr()[0], time_used=time.time() - time_start,
                            params=cfg.params, dataset_name=cfg.dataset.name)
        time_start = time.time()  # 重新记录时间起点，用于计算下一个批次的训练时间


@torch.no_grad()
# logger: 日志记录器，用于收集评估过程中的统计数据。loader: 数据加载器，提供评估批次数据。
# model: 已训练好的深度学习模型。split='val': 默认为验证集，但在函数内部可以根据需要修改为'test'或其他评估集。
def eval_epoch(logger, loader, model, split='val'):  # 评估函数，用于在给定数据加载器(loader)上计算模型的预测结果和损失
    model.eval()  # 设置为评估模式，关闭Dropout、BatchNorm等模块
    time_start = time.time()  # 记录当前时间点，用于计算每个批次评估所用的时间。
    for batch in loader:  # 遍历数据加载器中的每个批次数据
        batch.split = split  # 设置批次数据的标签为给定的split值，比如'val'（默认）或'test'。
        batch.to(torch.device(cfg.accelerator))  # to.GPU
        if cfg.gnn.head == 'inductive_edge':  # graph
            pred, true, extra_stats = model(batch)  # 返回预测结果、真实标签以及额外统计信息
        else:
            pred, true = model(batch)
            extra_stats = {}  # 返回预测结果和真实标签，初始化空字典extra_stats
        b=batch.lab
        if cfg.dataset.name == 'THUEACT50':
            loss, pred_score = compute_loss(pred, true)
            _true = true.detach().to('cpu', non_blocking=True)
            _pred = pred_score.detach().to('cpu', non_blocking=True)
        logger.update_stats(true=_true, pred=_pred, loss=loss.detach().cpu().item(), lr=0, time_used=time.time() - time_start,
                            params=cfg.params, dataset_name=cfg.dataset.name, **extra_stats)  # 更新参数
        time_start = time.time()  # 重新记录时间起点


@register_train('custom')  # 注册训练函数，当训练模式为custom时调用此函数
def custom_train(loggers, loaders, model, optimizer, scheduler):
    """
    Customized training 流程.

    Args:
        loggers: List of loggers
        loaders: List of loaders
        model: GNN model
        optimizer: PyTorch optimizer
        scheduler: PyTorch learning rate scheduler

    """
    start_epoch = 0  # 初始化起始训练轮数start_epoch
    if cfg.train.auto_resume:  # False，如果配置文件中启用了自动恢复训练，则尝试加载检查点并更新start_epoch。
        start_epoch = load_ckpt(model, optimizer, scheduler, cfg.train.epoch_resume)
    if start_epoch == cfg.optim.max_epoch:  # cfg.optim.max_epoch=100，达到最大训练轮数，则提示任务已完成
        logging.info('Checkpoint found, Task already done')
    else:
        logging.info('Start from epoch %s', start_epoch)

    if cfg.wandb.use:  # False
        try:
            import wandb
        except:
            raise ImportError('WandB is not installed.')
        if cfg.wandb.name == '':
            wandb_name = make_wandb_name(cfg)
        else:
            wandb_name = cfg.wandb.name
        run = wandb.init(entity=cfg.wandb.entity, project=cfg.wandb.project, name=wandb_name)
        run.config.update(cfg_to_dict(cfg))

    num_splits = len(loggers)  # 3，获取日志器的数量（对应训练、验证、测试3个阶段）
    split_names = ['val', 'test']
    full_epoch_times = []  # 记录每个阶段完整轮次耗时的列表full_epoch_times
    perf = [[] for _ in range(num_splits)]  # perf=[[],[],[]]
    for cur_epoch in range(start_epoch, cfg.optim.max_epoch):  # range(0,100)
        
        start_time = time.perf_counter()  # 记录开始时间
        train_epoch(loggers[0], loaders[0], model, optimizer, scheduler, cfg.optim.batch_accumulation)  # 执行一个epoch，调用train_epoch函数
        perf[0].append(loggers[0].write_epoch(cur_epoch))  # 将训练当前epoch添加到perf[0]中

        if is_eval_epoch(cur_epoch):  # 判断是否为评估epoch
            for i in range(1, num_splits):  # 依次对val和test进行评估，并将结果添加到perf[1],perf[2]中
                eval_epoch(loggers[i], loaders[i], model, split=split_names[i - 1])
                perf[i].append(loggers[i].write_epoch(cur_epoch))
        else:  # 验证和测试阶段的性能指标保持不变。
            for i in range(1, num_splits):
                perf[i].append(perf[i][-1])

        val_perf = perf[1]  # 验证集的性能指标为perf[1]
        if cfg.optim.scheduler == 'reduce_on_plateau':  # 根据优化器调度器类型更新学习率
            scheduler.step(val_perf[-1]['loss'])
        else:
            scheduler.step()
        full_epoch_times.append(time.perf_counter() - start_time)  # 记录本轮次的完整耗时并加入full_epoch_times列表
        # 具有常规频率的检查点（如果启用）。
        if cfg.train.enable_ckpt and not cfg.train.ckpt_best and is_ckpt_epoch(cur_epoch):
            save_ckpt(model, optimizer, scheduler, cur_epoch)

        if cfg.wandb.use:  # 如果使用WandB，则将当前轮次的性能指标上传到WandB
            run.log(flatten_dict(perf), step=cur_epoch)

        # 记录eval epoch的当前最佳统计数据.
        if is_eval_epoch(cur_epoch):
            best_epoch = np.array([vp['loss'] for vp in val_perf]).argmin()  # 计算验证集（val_perf）中损失（loss）最小的轮次best_epoch
            best_train = best_val = best_test = ""  # 初始化
            if cfg.metric_best != 'auto':
                # 根据`cfg.metric_best`的val性能再次选择。
                m = cfg.metric_best
                # 通过getattr方法和cfg.metric_agg参数（聚合函数，如最小值或最大值）找到val_perf中该指标最优的轮次。
                best_epoch = getattr(np.array([vp[m] for vp in val_perf]), cfg.metric_agg)()
                if m in perf[0][best_epoch]:
                    best_train = f"train_{m}: {perf[0][best_epoch][m]:.4f}"
                else:
                    # Note: 对于某些数据集，计算成本太高
                    # 训练集中的主要指标.
                    best_train = f"train_{m}: {0:.4f}"
                best_val = f"val_{m}: {perf[1][best_epoch][m]:.4f}"
                best_test = f"test_{m}: {perf[2][best_epoch][m]:.4f}"

                if cfg.wandb.use:  # 录到WandB运行的统计信息中，并更新全局平均和总耗时。
                    bstats = {"best/epoch": best_epoch}
                    for i, s in enumerate(['train', 'val', 'test']):
                        bstats[f"best/{s}_loss"] = perf[i][best_epoch]['loss']
                        if m in perf[i][best_epoch]:
                            bstats[f"best/{s}_{m}"] = perf[i][best_epoch][m]
                            run.summary[f"best_{s}_perf"] = perf[i][best_epoch][m]
                        for x in ['hits@1', 'hits@3', 'hits@10', 'mrr']:
                            if x in perf[i][best_epoch]:
                                bstats[f"best/{s}_{x}"] = perf[i][best_epoch][x]
                    run.log(bstats, step=cur_epoch)
                    run.summary["full_epoch_time_avg"] = np.mean(full_epoch_times)
                    run.summary["full_epoch_time_sum"] = np.sum(full_epoch_times)
            # Checkpoint the best epoch params (if enabled).
            if cfg.train.enable_ckpt and cfg.train.ckpt_best and best_epoch == cur_epoch:
                save_ckpt(model, optimizer, scheduler, cur_epoch)
                if cfg.train.ckpt_clean:  # 每次删除旧的ckpt。
                    clean_ckpt()
            # 输出各项指标
            logging.info(f"> Epoch {cur_epoch}: took {full_epoch_times[-1]:.1f}s "
                f"(avg {np.mean(full_epoch_times):.1f}s) | "
                f"Best so far: epoch {best_epoch}\t"
                f"train_loss: {perf[0][best_epoch]['loss']:.4f} {best_train}\t"
                f"val_loss: {perf[1][best_epoch]['loss']:.4f} {best_val}\t"
                f"test_loss: {perf[2][best_epoch]['loss']:.4f} {best_test}")
            if hasattr(model, 'trf_layers'):
                # 记录SAN的gamma参数值（如果它们是可训练的）.
                for li, gtl in enumerate(model.trf_layers):
                    if torch.is_tensor(gtl.attention.gamma) and gtl.attention.gamma.requires_grad:
                        logging.info(f"{gtl.__class__.__name__} {li}: " f"gamma={gtl.attention.gamma.item()}")
    logging.info(f"Avg time per epoch: {np.mean(full_epoch_times):.2f}s")  # 打印平均每轮耗时和总训练时间
    logging.info(f"Total train loop time: {np.sum(full_epoch_times) / 3600:.2f}h")
    for logger in loggers:  # 关闭所有日志器
        logger.close()
    if cfg.train.ckpt_clean:  # 如果配置要求清理检查点，则清理旧的检查点文件。
        clean_ckpt()
    # close wandb
    if cfg.wandb.use:  # 结束WandB运行
        run.finish()
        run = None

    logging.info('Task done, results saved in %s', cfg.run_dir)  # 提示训练完成，结果已保存在指定目录。

