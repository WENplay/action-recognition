import torch
import torch_geometric.graphgym.register as register
from torch_geometric.graphgym.config import cfg
from torch_geometric.graphgym.models.gnn import GNNPreMP
from torch_geometric.graphgym.models.layer import (new_layer_config, BatchNorm1dNode)
from torch_geometric.graphgym.register import register_network

from graphgps.layer.gps_layer import GPSLayer


class FeatureEncoder(torch.nn.Module):
    """
    编码节点和边缘特征

    Args:
        dim_in (int): 输入特征维度
    """
    def __init__(self, dim_in):
        super(FeatureEncoder, self).__init__()
        self.dim_in = dim_in  # 11
        if cfg.dataset.node_encoder:  # True
            # 通过nn.Embeddings对整数节点特征进行编码 
            NodeEncoder = register.node_encoder_dict[cfg.dataset.node_encoder_name]  # LapPE
            self.node_encoder = NodeEncoder(cfg.gnn.dim_inner)
            if cfg.dataset.node_encoder_bn:  # False
                self.node_encoder_bn = BatchNorm1dNode(new_layer_config(cfg.gnn.dim_inner, -1, -1, has_act=False, has_bias=False, cfg=cfg)) # 创建批标准化层
            # 更新dim_in以反映节点特征的新维度
            self.dim_in = cfg.gnn.dim_inner  # 11
        if cfg.dataset.edge_encoder:  # True
            # PNA的硬限制最大边缘尺寸。
            if 'PNA' in cfg.gt.layer_type:  # False
                cfg.gnn.dim_edge = min(128, cfg.gnn.dim_inner)
            else:
                cfg.gnn.dim_edge = cfg.gnn.dim_inner  # 52
            # 对整数边缘特征进行编码 nn.Embeddings
            EdgeEncoder = register.edge_encoder_dict[cfg.dataset.edge_encoder_name]  # LinearEdge
            self.edge_encoder = EdgeEncoder(cfg.gnn.dim_edge)  # 52
            if cfg.dataset.edge_encoder_bn:  # False
                self.edge_encoder_bn = BatchNorm1dNode(new_layer_config(cfg.gnn.dim_edge, -1, -1, has_act=False, has_bias=False, cfg=cfg))

    def forward(self, batch):
        for module in self.children():
            batch = module(batch)  # include LapPENodeEnconder and LinearEdgeEnconder
        return batch

#  DataBatch(x=[8192, 52], edge_index=[2, 216], edge_attr=[216, 52], y=[16], EigVals=[8192, 8, 1], EigVecs=[8192, 8], batch=[8192], ptr=[17], split='train')

@register_network('GPSModel')
class GPSModel(torch.nn.Module):
    """通用强大的可扩展图transformer.
    https://arxiv.org/abs/2205.12454 Rampasek, L., Galkin, M., Dwivedi, V. P., Luu, A. T., Wolf, G., & Beaini, D.
    Recipe for a general, powerful, scalable graph transformer. (NeurIPS 2022)
    """

    def __init__(self, dim_in, dim_out):
        super().__init__()
        self.encoder = FeatureEncoder(dim_in)
        dim_in = self.encoder.dim_in

        if cfg.gnn.layers_pre_mp > 0:  # 0
            self.pre_mp = GNNPreMP(dim_in, cfg.gnn.dim_inner, cfg.gnn.layers_pre_mp)
            dim_in = cfg.gnn.dim_inner

        if not cfg.gt.dim_hidden == cfg.gnn.dim_inner == dim_in:  # False
            raise ValueError(f"The inner and hidden dims must match: "
                f"embed_dim={cfg.gt.dim_hidden} dim_inner={cfg.gnn.dim_inner} " f"dim_in={dim_in}")

        try:
            local_gnn_type, global_model_type = cfg.gt.layer_type.split('+')
            #  local_gnn_type='CustomGatedGCN',global_model_type='Transformer'
        except:
            raise ValueError(f"Unexpected layer type: {cfg.gt.layer_type}")
        layers = []
        for _ in range(cfg.gt.layers):  # 3
            layers.append(GPSLayer(
                dim_h=cfg.gt.dim_hidden,  # 52
                local_gnn_type=local_gnn_type,
                global_model_type=global_model_type,
                num_heads=cfg.gt.n_heads,  # 4
                act=cfg.gnn.act,  # relu
                pna_degrees=cfg.gt.pna_degrees,  # []
                equivstable_pe=cfg.posenc_EquivStableLapPE.enable, # False
                dropout=cfg.gt.dropout,  # 0.0
                attn_dropout=cfg.gt.attn_dropout,  # 0.5
                layer_norm=cfg.gt.layer_norm,  # False
                batch_norm=cfg.gt.batch_norm,  # True
                log_attn_weights=cfg.train.mode == 'log-attn-weights',))
        self.layers = torch.nn.Sequential(*layers)  # 创建一个包含三层GPSLayer（）的容器

        GNNHead = register.head_dict[cfg.gnn.head]  # default
        self.post_mp = GNNHead(dim_in=cfg.gnn.dim_inner, dim_out=dim_out)

    def forward(self, batch):
        for module in self.children():
            batch = module(batch)  
            # FeatureEnconder(LapPENodeEnconder+LinearEdgeEnconder)+GatedGCNLayer+mtil-head-attention+残差
        return batch
