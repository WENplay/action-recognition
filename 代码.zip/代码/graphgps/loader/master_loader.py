import logging
import os.path as osp
import time
from functools import partial

import numpy as np
import torch
import torch_geometric.transforms as T
from torch_geometric.graphgym.config import cfg
from torch_geometric.graphgym.loader import load_pyg
from torch_geometric.graphgym.register import register_loader

from graphgps.loader.dataset.ThuSuperpixels import Thueact50Superpixels
from graphgps.loader.split_generator import (prepare_splits, set_dataset_splits)
from graphgps.transform.posenc_stats import compute_posenc_stats
from graphgps.transform.task_preprocessing import task_specific_preprocessing
from graphgps.transform.transforms import pre_transform_in_memory


def log_loaded_dataset(dataset, format, name):
    logging.info(f"[*] Loaded dataset '{name}' from '{format}':")
    logging.info(f"  {dataset.data}")
    logging.info(f"  undirected: {dataset[0].is_undirected()}")
    logging.info(f"  num graphs: {len(dataset)}")

    total_num_nodes = 0
    if hasattr(dataset.data, 'num_nodes'):
        total_num_nodes = dataset.data.num_nodes
    elif hasattr(dataset.data, 'x'):
        total_num_nodes = dataset.data.x.size(0)
    logging.info(f"  avg num_nodes/graph: " f"{total_num_nodes // len(dataset)}")
    logging.info(f"  num node features: {dataset.num_node_features}")
    logging.info(f"  num edge features: {dataset.num_edge_features}")
    if hasattr(dataset, 'num_tasks'):
        logging.info(f"  num tasks: {dataset.num_tasks}")

    if hasattr(dataset.data, 'y') and dataset.data.y is not None:
        if isinstance(dataset.data.y, list):
            # A special case for ogbg-code2 dataset.
            logging.info(f"  num classes: n/a")
        elif dataset.data.y.numel() == dataset.data.y.size(0) and torch.is_floating_point(dataset.data.y):
            logging.info(f"  num classes: (appears to be a regression task)")
        else:
            logging.info(f"  num classes: {dataset.num_classes}")
    elif hasattr(dataset.data, 'train_edge_label') or hasattr(dataset.data, 'edge_label'):
        # Edge/link prediction task.
        if hasattr(dataset.data, 'train_edge_label'):
            labels = dataset.data.train_edge_label  # Transductive link task
        else:
            labels = dataset.data.edge_label  # Inductive link task
        if labels.numel() == labels.size(0) and torch.is_floating_point(labels):
            logging.info(f"  num edge classes: (probably a regression task)")
        else:
            logging.info(f"  num edge classes: {len(torch.unique(labels))}")

    ## Show distribution of graph sizes.
    # graph_sizes = [d.num_nodes if hasattr(d, 'num_nodes') else d.x.shape[0] for d in dataset]
    # hist, bin_edges = np.histogram(np.array(graph_sizes), bins=10)
    # logging.info(f'   Graph size distribution:')
    # logging.info(f'     mean: {np.mean(graph_sizes)}')
    # for i, (start, end) in enumerate(zip(bin_edges[:-1], bin_edges[1:])):
    #     logging.info(f'     bin {i}: [{start:.2f}, {end:.2f}]: ' f'{hist[i]} ({hist[i] / hist.sum() * 100:.2f}%)')


@register_loader('custom_master_loader')
def load_dataset_master(format, name, dataset_dir):
    """
    控制所有数据集加载的主加载程序，掩盖执行任何默认GraphGym数据集加载程序。
    默认的GraphGym数据集加载程序是从该函数调用的，格式关键字“PyG”和“OGB”是为这些默认的GraphiGym加载程序保留的。

    自定义转换和数据集拆分应用于每个加载的数据集。

    Args:
        format: 标识数据集类的数据集格式名称
        name: 要从“format”标识的类中选择的数据集名称`
        dataset_dir: 存储已处理数据集的路径
    Returns:
        应用扰动变换的PyG数据集对象 and 数据拆分
    """
    if format.startswith('PyG-'):
        pyg_dataset_id = format.split('-', 1)[1]
        dataset_dir = osp.join(dataset_dir, pyg_dataset_id)

        if pyg_dataset_id == 'Thueact50Superpixels':
            dataset = preformat_Thueact50Superpixels(dataset_dir, name)
        else:
            raise ValueError(f"Unexpected PyG Dataset identifier: {format}")

    # Pytorch Geometric数据集的GraphGym默认加载程序
    # dataset_dir=root=/home/user/THU-EACT-50-V2(feature_change)/dataset/
    elif format == 'PyG':
        dataset = load_pyg(name, dataset_dir)

    else:
        raise ValueError(f"Unknown data format: {format}")

    pre_transform_in_memory(dataset, partial(task_specific_preprocessing, cfg=cfg))

    log_loaded_dataset(dataset, format, name)

    # 预先计算位置编码所需的统计信息。
    pe_enabled_list = []
    for key, pecfg in cfg.items():  # pecfg=‘both'，key=’print'
        if key.startswith('posenc_') and pecfg.enable:
            pe_name = key.split('_', 1)[1]  # 获取位置编码用的'LapPE'
            pe_enabled_list.append(pe_name)
            if hasattr(pecfg, 'kernel'):
                # Generate kernel times if functional snippet is set.
                if pecfg.kernel.times_func:
                    pecfg.kernel.times = list(eval(pecfg.kernel.times_func))
                logging.info(f"Parsed {pe_name} PE kernel times / steps: "
                             f"{pecfg.kernel.times}")
    if pe_enabled_list:  # ['LapPE']
        start = time.perf_counter()
        logging.info(f"Precomputing Positional Encoding statistics: " f"{pe_enabled_list} for all graphs...")
        # 根据10张图来估计方向性以节省时间。
        is_undirected = all(d.is_undirected() for d in dataset[:10])  # True
        logging.info(f"  ...estimated to be undirected: {is_undirected}")
        pre_transform_in_memory(dataset, partial(compute_posenc_stats,
                                        pe_types=pe_enabled_list,
                                        is_undirected=is_undirected,
                                        cfg=cfg), show_progress=True )
        elapsed = time.perf_counter() - start
        timestr = time.strftime('%H:%M:%S', time.gmtime(elapsed)) + f'{elapsed:.2f}'[-3:]
        logging.info(f"Done! Took {timestr}")

    # 设置标准数据集 train/val/test splits
    if hasattr(dataset, 'split_idxs'):
        set_dataset_splits(dataset, dataset.split_idxs)
        delattr(dataset, 'split_idxs')

    # 验证或生成数据集 train/val/test splits
    prepare_splits(dataset)

    # 如果PNAConv需要，在度直方图中进行预计算。
    if cfg.gt.layer_type.startswith('PNA') and len(cfg.gt.pna_degrees) == 0:
        cfg.gt.pna_degrees = compute_indegree_histogram(dataset[dataset.data['train_graph_index']])
        # print(f"Indegrees: {cfg.gt.pna_degrees}")
        # print(f"Avg:{np.mean(cfg.gt.pna_degrees)}")

    return dataset


def compute_indegree_histogram(dataset):
    """计算PNAConv所需节点的直方图。

    Args:
        dataset: PyG Dataset object

    Returns:
        列出其中第i个值是阶数等于`i`的节点数
    """
    from torch_geometric.utils import degree

    deg = torch.zeros(1000, dtype=torch.long)
    max_degree = 0
    for data in dataset:
        d = degree(data.edge_index[1],
                   num_nodes=data.num_nodes, dtype=torch.long)
        max_degree = max(max_degree, d.max().item())
        deg += torch.bincount(d, minlength=deg.numel())
    return deg.numpy().tolist()[:max_degree + 1]

def preformat_Thueact50Superpixels(dataset_dir, name):
    """加载并预格式化Thueact50超级像素数据集。

    Args:
        dataset_dir: 存储缓存数据集的路径
    Returns:
        PyG数据集对象
    """
    dataset = join_dataset_splits([Thueact50Superpixels(dataset_dir, name, split=split)
         for split in ['train', 'val', 'test']])
    return dataset


def join_dataset_splits(datasets):
    """将train、val和test数据集连接到一个数据集对象中。

    Args:
        datasets: 要合并的3个PyG数据集的列表

    Returns:
        具有存储拆分索引的“split_idxs”属性的联合数据集
    """
    assert len(datasets) == 3, "期望train、val、test数据集"

    n1, n2, n3 = len(datasets[0]), len(datasets[1]), len(datasets[2])
    data_list = [datasets[0].get(i) for i in range(n1)] + [datasets[1].get(i) for i in range(n2)] + [datasets[2].get(i) for i in range(n3)]

    datasets[0]._indices = None
    datasets[0]._data_list = data_list
    datasets[0].data, datasets[0].slices = datasets[0].collate(data_list)
    split_idxs = [list(range(n1)), list(range(n1, n1 + n2)), list(range(n1 + n2, n1 + n2 + n3))]
    datasets[0].split_idxs = split_idxs

    return datasets[0]
