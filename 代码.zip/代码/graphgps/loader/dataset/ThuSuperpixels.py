import os
import os.path as osp
import re
import torch
import torch.nn as nn
from tqdm import tqdm
from torch_geometric.data import (InMemoryDataset, Data)

class Thueact50Superpixels(InMemoryDataset):

    def __init__(self, root, name, transform=None, pre_transform=None, pre_filter=None):  
        self.root=root  # '/media/ywb/Dataset/THU-EACT-50/THU-EACT-50/c1t/'
        self.name = name  # THUEACT50
        split='total'
        super().__init__(root, transform, pre_transform, pre_filter)
        path = osp.join(self.processed_dir, f'{split}.pt')
        self.data, self.slices = torch.load(path)
    
    @property
    def processed_dir(self):
        return osp.join(self.root, 'vs3/num=512,d=7/')

    @property
    def processed_file_names(self):
        return ['total.pt']
        
    # 定义一个函数用于提取文件名中的数字部分
    def extract_number(self, file_name):  # 这个函数适用于对文件名列表进行排序，按照排序结果和idx划分train,val,test
        # 假设文件名格式为 "A任意数字B任意字符..."
        # 使用正则表达式匹配数字
        match = re.match(r'A(\d+)P', file_name)
        if match:
            return int(match.group(1))  # 返回匹配到的数字
        else:
            # 如果没有匹配到A和B之间的数字，则返回一个非常大的数，使其排在列表末尾
            return float('inf')
    
    def process_data(self, eoo, poo):
        num_edges = eoo.size(1)
        new_edge_index = torch.empty((2, 0), dtype=torch.long)
        for i in range(0, num_edges, 2):
            node1_idx, node2_idx = eoo[:, i]
            node1_time = poo[node1_idx][2]
            node2_time = poo[node2_idx][2]
            if node1_time < node2_time:
                new_edge_index = torch.cat((new_edge_index, eoo[:, i].view(2, 1)), dim=1)
            else:
                new_edge_index = torch.cat((new_edge_index, eoo[:, i].flip(0).view(2, 1)), dim=1)
        return new_edge_index
    
    def edge_feature(self,graph):
        e_index = graph.edge_index.to(torch.int).tolist()  # 边的索引
        d_pos = []  # 采用两点之间的欧氏距离作为边的特征
        p = graph.x[:,:3].tolist()  # 节点的位置信息
        for i in range(len(e_index[0])):
            one_node_index = e_index[0][i]
            two_node_index = e_index[1][i]  # 两个节点的索引

            one_node_pos = p[one_node_index]
            two_node_pos = p[two_node_index]  # 通过两个节点的索引找到其对应的位置坐标
            
            if i % 2==0:  # 边的索引为偶数项
                if one_node_pos[0] >= two_node_pos[0]:
                    d_txy=[a - b for a, b in zip(one_node_pos,two_node_pos)]
                else:
                    d_txy=[a - b for a, b in zip(two_node_pos,one_node_pos)]
            else:
                if one_node_pos[0] > two_node_pos[0]:
                    d_txy=[a - b for a, b in zip(one_node_pos,two_node_pos)]
                else:
                    d_txy=[a - b for a, b in zip(two_node_pos,one_node_pos)]

            d_pos.append(d_txy)

        return torch.tensor(d_pos)  # 返回边的特征
    
    def process(self):
        path=osp.join(self.root,'3-7-512/')  # '/media/ywb/Dataset/THU-EACT-50/THU-EACT-50/c1t/voxel_size=1/num=512,d=3/'
        
        with open('/home/ywb/code/thu1/train.txt', 'r', encoding='utf-8') as file:
            # 读取文件的每一行，并去除尾部的换行符，然后存储到列表中
            lines_train = [line.strip() for line in file]
        with open('/home/ywb/code/thu1/test.txt', 'r', encoding='utf-8') as file:
            # 读取文件的每一行，并去除尾部的换行符，然后存储到列表中
            lines_test = [line.strip() for line in file]
        
        
        
        file_list = os.listdir(path)
        pbar = tqdm(len(file_list))
        data_list=[]
        for i in file_list:
            i_root=os.path.join(path,i)
            graph=torch.load(i_root)
            
            if i in lines_train:
                a='train'
            elif i in lines_test:
                a='test'
            else:
                a='val'

            x = graph.x.to(torch.float)   # 节点的特征矩阵
            position=x[:,:3]
            x=x[:,3:]
            
            edge_index = self.process_data(graph.edge_index,position)  # 边的索引矩阵
            edge_index_expanded = graph.edge_index.repeat(1, 2).view(2, -1)[:, :2 * edge_index.size(1)]

            edgefeature=self.edge_feature(graph)
            edge_attr = edgefeature.to(torch.float)  # 边的特征矩阵

            data = Data(x=x, position=position, undir_edge_index=graph.edge_index, edge_index=edge_index_expanded, edge_attr=edge_attr, y=graph.y, lab=a,name=i)  # 重新生成数据

            if self.pre_filter is not None and not self.pre_filter(data):
                continue

            if self.pre_transform is not None:
                data = self.pre_transform(data)

            data_list.append(data)  # 将生成的data数据添加进入列表 
            pbar.update(1)            
        
        
        
        
        
        
        '''
        
        file_list = os.listdir(path)
        Graph_file_list = [os.path.join(path,file) for file in file_list]
        indices = len(Graph_file_list) # train/val/test的数据数量

        pbar = tqdm(indices)
        pbar.set_description(f'Processing total dataset')
        data_list = []
        for idx in range(indices):
            graph=torch.load(Graph_file_list[idx])  # 读取文件中的数据 
            """
            Each `graph` is a tuple (x, edge_attr, edge_index, y)
                Shape of x : [num_nodes, 11]
                Shape of edge_attr : [num_edges, 1] or [num_edges, 2]
                Shape of edge_index : [2, num_edges]
                Shape of y : [num_nodes]
            """

            # 数据集划分，判断数据集名称P之后C之前的数字范围（代表人），前85（标号10-94）为train，中间10（标号95-104）为val，最后10（标号105-114）为test
            name=os.path.basename(Graph_file_list[idx])  # 首先提取出此idx下的完整路径，接着提取路径中的文件名称
            match= re.search(r'P(\d+)C', name)  # 匹配文件名称中的P-C之间的数字，也就是人的标号
            number = int(match.group(1))
            
            if number < 95:
                a='train'
            elif 95 <= number < 115:
                a='test'
            else:
                a='val'
            # 到此数据集划分完成
            
            x = graph.x.to(torch.float)   # 节点的特征矩阵
            position=x[:,:3]
            x=x[:,3:]
            
            edge_index = self.process_data(graph.edge_index,position)  # 边的索引矩阵
            edge_index_expanded = graph.edge_index.repeat(1, 2).view(2, -1)[:, :2 * edge_index.size(1)]

            edgefeature=self.edge_feature(graph)
            edge_attr = edgefeature.to(torch.float)  # 边的特征矩阵

            data = Data(x=x, position=position, undir_edge_index=graph.edge_index, edge_index=edge_index_expanded, edge_attr=edge_attr, y=graph.y, lab=a,name=name)  # 重新生成数据

            if self.pre_filter is not None and not self.pre_filter(data):
                continue

            if self.pre_transform is not None:
                data = self.pre_transform(data)

            data_list.append(data)  # 将生成的data数据添加进入列表 
            pbar.update(1)'''

        pbar.close()
        # 将list转化为tuple，即data转化为内部存储InMemoryDataset格式，并存储于total.pt中
        torch.save(self.collate(data_list), osp.join(self.processed_dir, 'total.pt'))  
