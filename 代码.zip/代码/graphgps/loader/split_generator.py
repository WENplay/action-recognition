'''import json
import logging
import os

import numpy as np
from sklearn.model_selection import ShuffleSplit'''
from torch_geometric.graphgym.config import cfg
from torch_geometric.graphgym.loader import index2mask, set_dataset_attr


def prepare_splits(dataset):
    """Ready train/val/test splits.

    从配置中确定拆分的类型，并调用相应的拆分生成/验证函数。
    """
    split_mode = cfg.dataset.split_mode

    if split_mode == 'standard':
        setup_standard_split(dataset)
    elif split_mode == "fixed":
        setup_fixed_split(dataset)
    elif split_mode == "sliced":
        # setup_sliced_split(dataset)
        setup_sliced_split_by_indices(dataset)
    else:
        raise ValueError(f"Unknown split mode: {split_mode}")


def setup_standard_split(dataset):
    """选择标准拆分.

    使用数据集附带的标准拆分。如果有多个拆分可用，请根据配置文件中的“split_index”选择一个拆分。

    GNNBenchmarkDataset具有未预先指定为掩码的拆分。因此，对它们进行不同的处理，并首先进行处理以生成masks。

    Raises:
        ValueError: 如果train/val/test mask中的任何一个缺失。
        IndexError: 如果“split_index”大于或等于可用拆分的总数。
    """
    split_index = cfg.dataset.split_index
    task_level = cfg.dataset.task

    if task_level == 'graph':
        for split_name in 'train_graph_index', 'val_graph_index', 'test_graph_index':
            if not hasattr(dataset.data, split_name): # 检查dataset.data是否具有split_name属性
                raise ValueError(f"Missing '{split_name}' for standard split")
        if split_index != 0:
            raise NotImplementedError(f"Multiple standard splits not supported " f"for dataset task level: {task_level}")

    else:
        if split_index != 0:
            raise NotImplementedError(f"Multiple standard splits not supported " f"for dataset task level: {task_level}")

def setup_fixed_split(dataset):
    """Generate fixed splits.
    
    根据配置文件中定义的比率生成固定train/val/test。
    """
    train_index = list(range(cfg.dataset.split[0]))
    val_index = list(range(cfg.dataset.split[0], sum(cfg.dataset.split[:2])))
    test_index = list(range(sum(cfg.dataset.split[:2]), sum(cfg.dataset.split)))

    set_dataset_splits(dataset, [train_index, val_index, test_index])


def setup_sliced_split(dataset):
    """Generate sliced splits.

    根据配置文件中定义的比率生成切片train/val/test。
    """
    train_index = list(range(70))
    val_index = list(range(70,80))
    test_index = list(range(80,100))

    set_dataset_splits(dataset, [train_index, val_index, test_index])

def setup_sliced_split_by_indices(dataset):
    """Generate indices for sliced splits based on the 'lab' attribute."""
    
    train_index = [i for i, item in enumerate(dataset) if item.lab == 'train']
    val_index = [i for i, item in enumerate(dataset) if item.lab == 'val']
    test_index = [i for i, item in enumerate(dataset) if item.lab == 'test']

    # 假设 set_dataset_splits 函数接受三个索引列表作为参数
    set_dataset_splits(dataset, [train_index, val_index, test_index])


def set_dataset_splits(dataset, splits):
    """为数据集对象设置给定的拆分。

    Args:
        dataset: PyG dataset object
        splits: List of train/val/test split indices

    Raises:
        ValueError: 如果任何一对分割具有相交索引
    """
    # 首先检查拆分是否相交，如果相交则引发错误。
    for i in range(len(splits) - 1):
        for j in range(i + 1, len(splits)):
            n_intersect = len(set(splits[i]) & set(splits[j]))
            if n_intersect != 0:
                raise ValueError(f"Splits must not have intersecting indices: "
                    f"split #{i} (n = {len(splits[i])}) and " f"split #{j} (n = {len(splits[j])}) have " f"{n_intersect} intersecting indices")

    task_level = cfg.dataset.task
    if task_level == 'node':
        split_names = ['train_mask', 'val_mask', 'test_mask']
        for split_name, split_index in zip(split_names, splits):
            mask = index2mask(split_index, size=dataset.data.y.shape[0])
            set_dataset_attr(dataset, split_name, mask, len(mask))

    elif task_level == 'graph':
        split_names = ['train_graph_index', 'val_graph_index', 'test_graph_index']
        for split_name, split_index in zip(split_names, splits):
            set_dataset_attr(dataset, split_name, split_index, len(split_index))

    else:
        raise ValueError(f"Unsupported dataset task level: {task_level}")

