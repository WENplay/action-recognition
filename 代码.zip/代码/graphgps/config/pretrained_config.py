from torch_geometric.graphgym.register import register_config
from yacs.config import CfgNode as CN


@register_config('cfg_pretrained')
def set_cfg_pretrained(cfg):
    """用于加载预训练模型的配置选项。
    """

    cfg.pretrained = CN()

    # 保存的实验的目录路径（如果设置），从那里加载模型，并在指定的数据集上对其进行微调/运行推理。
    cfg.pretrained.dir = ""

    # 丢弃预测head的预训练权重并重新初始化。
    cfg.pretrained.reset_prediction_head = True

    # 固定模型的主要预训练“body”，只学习新的head
    cfg.pretrained.freeze_main = False
