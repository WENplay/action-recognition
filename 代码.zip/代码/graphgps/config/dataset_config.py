from torch_geometric.graphgym.register import register_config


@register_config('dataset_cfg')
def dataset_cfg(cfg):
    """特定于数据集的配置选项。
    """

    # TypeDictNodeEncoder中预期的节点类型数。
    cfg.dataset.node_encoder_num_types = 0

    # TypeDictEdgeEncoder中需要的边缘类型数。
    cfg.dataset.edge_encoder_num_types = 0

    # 基于SLIC紧致度参数的VOC/COCO Superpixels数据集版本。
    cfg.dataset.slic_compactness = 10

    # 推断链路参数（例如，边缘预测任务）
    cfg.dataset.infer_link_label = "None"
