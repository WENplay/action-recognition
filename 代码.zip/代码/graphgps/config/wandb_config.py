from torch_geometric.graphgym.register import register_config
from yacs.config import CfgNode as CN


@register_config('cfg_wandb')
def set_cfg_wandb(cfg):
    """Weights & Biases tracker configuration.
    """

    # WandB group
    cfg.wandb = CN()

    # Use wandb or not
    cfg.wandb.use = False

    # Wandb实体名称，应预先存在
    cfg.wandb.entity = "gtransformers"

    # Wandb项目名称，如果不存在，将在您的团队中创建
    cfg.wandb.project = "gtblueprint"

    # 可选运行名称
    cfg.wandb.name = ""
