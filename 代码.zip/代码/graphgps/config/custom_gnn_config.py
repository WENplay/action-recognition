from torch_geometric.graphgym.register import register_config


@register_config('custom_gnn')
def custom_gnn_cfg(cfg):
    """为了我们的CustomGNN网络模型的目的，扩展GraphGym内置GNN的配置组。
    """

    # 使用GNN层之间的残差连接。
    cfg.gnn.residual = False
