from torch_geometric.graphgym.register import register_config


@register_config('extended_optim')
def extended_optim_cfg(cfg):
    """扩展GraphGym在torch_geometric.GraphGym.config.set_cfg中首先设置的优化器配置组
    """

    # 更新参数前累积梯度的批次数需要“自定义”训练循环，设置“训练模式：自定义`
    cfg.optim.batch_accumulation = 1

    # ReduceLROnPlateau：学习率降低的因素
    cfg.optim.reduce_factor = 0.1

    # ReduceLROnPlateau: 没有改善epoch，之后LR减少
    cfg.optim.schedule_patience = 10

    # ReduceLROnPlateau: 学习率下限
    cfg.optim.min_lr = 0.0

    # 对于具有预热阶段的调度器，设置时期的预热数量
    cfg.optim.num_warmup_epochs = 50

    # 训练时剪裁渐变规范
    cfg.optim.clip_grad_norm = False
    cfg.optim.clip_grad_norm_value = 1.0
