from torch_geometric.graphgym.register import register_config


@register_config('overwrite_defaults')
def overwrite_defaults_cfg(cfg):
    """覆盖GraphGym在torch_geometric.GraphGym.config.set_cfg中首先设置的默认配置值

    WARNING: 在撰写本文时，像这样的自定义配置设置函数的执行顺序是随机的；请参阅引用的“set_cfg”，因此永远不要在此处重置自定义添加的配置选项，只更改核心GraphGym中存在的配置选项。
    """

    # Training (and validation) pipeline mode
    cfg.train.mode = 'custom'  # 'standard' uses PyTorch-Lightning since PyG 2.1

    # 覆盖默认数据集名称
    cfg.dataset.name = 'none'

    # 覆盖默认舍入精度
    cfg.round = 5


@register_config('extended_cfg')
def extended_cfg(cfg):
    """常规扩展配置选项。
    """

    # 在“run_dir”和“wandb_name”自动生成中使用的附加名称标记。
    cfg.name_tag = ""

    # 在训练中，如果True（以及cfg.train.enable_ckpt为True），则始终根据验证性能检查当前最佳模型，而当False时，则遵循cfg.train_eval_period检查点频率。
    cfg.train.ckpt_best = False
