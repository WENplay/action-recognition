from torch_geometric.graphgym.register import register_config
from yacs.config import CfgNode as CN


@register_config('cfg_gt')
def set_cfg_gt(cfg):
    """图形转换器样式模型的配置，例如：
    - 频谱注意力网络（SAN）图转换器。
    - "vanilla" Transformer / Performer.
    - 通用强大可扩展（GPS）模型。
    """

    # 位置编码参数组
    cfg.gt = CN()

    # 要使用的图形转换器层的类型
    cfg.gt.layer_type = 'SANLayer'

    # 模型中的变压器层数
    cfg.gt.layers = 3

    # 图转换器中的注意力头数
    cfg.gt.n_heads = 8

    # 隐藏节点和边表示的大小
    cfg.gt.dim_hidden = 64

    # 充分注意SAN转换器，包括所有可能的成对边缘
    cfg.gt.full_graph = True

    # SAN真实与虚假边缘注意力加权系数
    cfg.gt.gamma = 1e-5

    # PNAConv使用的训练集中节点的直方图（以度为单位）。
    # 当`gt.layer_type:PNAConv+…`时使用。如果为空，则在数据集加载过程中对其进行预计算。
    cfg.gt.pna_degrees = []

    # 前馈模块中的dropout。
    cfg.gt.dropout = 0.0

    # Dropout in self-attention.
    cfg.gt.attn_dropout = 0.0

    cfg.gt.layer_norm = False

    cfg.gt.batch_norm = True

    cfg.gt.residual = True
