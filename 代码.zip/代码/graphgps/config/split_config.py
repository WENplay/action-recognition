from torch_geometric.graphgym.register import register_config


@register_config('split')
def set_cfg_split(cfg):
    """重新配置数据集拆分选项的默认配置值。

    Returns:
        实验使用的重新配置的拆分配置。
    """

    # 默认选择随数据集一起提供的标准拆分
    cfg.dataset.split_mode = 'standard'

    # 如果有多个拆分可用，请选择要使用的特定拆分
    cfg.dataset.split_index = 0

    # 缓存交叉验证拆分的目录
    cfg.dataset.split_dir = './splits'

    # 选择在一个程序执行中运行多个拆分，如果已设置，则拆分选择的优先级高于cfg.dataset.split_index
    cfg.run_multiple_splits = []
