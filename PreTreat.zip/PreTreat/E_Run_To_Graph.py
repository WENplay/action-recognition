import os
from tqdm import tqdm
from B_To_Voxel import voxel
from D_data_change import Npz_to_Data
from C_Graph_edge import calculate_edges
from A_Read_CSV_To_Npy import read_csv_to_npy

Initial_event_path='/home/data/THU-50/C2/'
Data_save_path='/home/data/THU-50/C2.pt/'

if __name__ == '__main__':
    event_files=[]
    if os.path.exists(Initial_event_path) and os.path.isdir(Initial_event_path):  # 检查路径是否存在并且是一个目录  
        event_files = os.listdir(Initial_event_path)  # 获取目录下的文件和文件夹列表 
    for eventName in tqdm(event_files):
        if os.path.isfile(os.path.join(Data_save_path, eventName)): 
            continue
        file=os.path.join(Initial_event_path, eventName)
        save_name =eventName.split('.')[0] # 保存文件名称，去掉后缀
        event_file=read_csv_to_npy(file)
        position,feature=voxel(event_file)  # event=[x,y,t,p]->position[x,y,t],feature[p*8]
        edge= calculate_edges(position)  
        Npz_to_Data(position,feature,edge,Data_save_path,save_name)

