import torch
import numpy as np
import scipy.sparse as sp
from spconv.pytorch.utils import PointToVoxel


def transform_points_to_voxels(data_dict = {}, device = torch.device("cuda:0")):
    points = data_dict['points']
    # 将points打乱
    shuffle_idx = np.random.permutation(points.shape[0])
    points = points[shuffle_idx] # 将原来的事件随机重排
    data_dict['points'] = points

    voxel_generator = PointToVoxel(
        # 给定每个voxel的长宽高  
        vsize_xyz=[10, 10, 10], 
        # 给定的范围 
        coors_range_xyz=[0, 0, 0, 1280, 800, 20000000],
        # 给定每个event的特征维度 t,x,y,p
        num_point_features=4,
        # 最多选取多少个voxel，
        max_num_voxels=10000,  
        # 给定每个voxel中有采样多少个点，不够则补0
        max_num_points_per_voxel=8,  # 32
        device=device
    )
    # 使用spconv生成voxel输出
    points = torch.tensor(data_dict['points']) # 转换为tensor张量
    points = points.to(device) # 移动到设备GPU
    voxel_output = voxel_generator(points)

    voxels, coordinates, num_points = voxel_output
    # pdb.set_trace()
    voxels = voxels.to(device)
    coordinates = coordinates.to(device)
    num_points = num_points.to(device)
    # 选event数量在前5000的voxel
    if num_points.shape[0] < 512:
        features = voxels[:,:,3]
        coor = coordinates[:,:]
    else:
        _, voxels_idx = torch.topk(num_points, 512)
    # 将每个voxel的1024个p拼接作为voxel初始特征
        features = voxels[voxels_idx][:, :, 3]
    # 前5000个voxel的三维坐标
        coor = coordinates[voxels_idx]
    # 将y.x.t改为t,x,y
    coor[:, [0, 1, 2]] = coor[:, [2, 1, 0]]

    return coor, features

def voxel(event_file):
    device = torch.device("cuda:0")
    event_file=np.array(event_file)
    t = event_file[:,2] # 提取出时间序列t和对应的坐标x、y和极值p
    mi=min(t)
    ma=max(t)        
    t = [(x - mi) * (1000.0 / (ma - mi)) for x in t] # 时间t归一化至0-200
    x = event_file[:,0].astype(np.float64)
    y = event_file[:,1].astype(np.float64) # 从mat_file中提取特定字段并转化为numpy.float类型
    p = event_file[:,3].astype(np.float64)
    # all_events = np.hstack((t,x,y,p)) # 将处理后的合并为一个新的数组
    all_events=[(a, b, c, d) for a, b, c, d in zip(t, x, y, p)] 
    all_events = torch.tensor(all_events).float() # 转化为pytorch tensor
    all_events = all_events.to(device) #移动到cpu或GPU上
    data_dict = {'points': all_events} # 构造字典，格式为{'points':[t,x,y,p]}
    coor, feature = transform_points_to_voxels(data_dict=data_dict, device=device)
    # 使用 transform_points_to_voxels 函数将点云数据转换为体素数据，并得到新的坐标 coor 和特征 features
    coor = coor.cpu()
    feature = feature.cpu() # 转化为cpu张量
    coor = coor.numpy() # 从tensor转化为numpy数组
    feature = feature.numpy()
    feature = np.hstack((coor, feature))
    # feature=normalize(feature)
    return coor, feature