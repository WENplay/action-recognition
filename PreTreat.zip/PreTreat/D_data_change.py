import os
import re
import torch
import numpy as np
from torch_geometric.data import Data

def Npz_to_Data(pos,fea,edg,spath,na):  # 输入position,feature edge,savepath,filename

    pos = torch.tensor(np.array(pos), dtype=torch.float32)
    
    feature = torch.tensor(fea).float()
    
    row_size_fea, column_size_fea = feature.shape
    batch = torch.tensor(row_size_fea, dtype=torch.long)
    
    edge_index = torch.tensor(np.array(edg).astype(np.int32), dtype=torch.long)
    
    match= re.search(r'A(\d+)P', na)
    number = int(match.group(1))
    label_idx = torch.tensor(number, dtype=torch.long)
    
    data = Data(edge_index=edge_index, x=feature, y=label_idx.unsqueeze(0),batch=batch.unsqueeze(0))
    torch.save(data, os.path.join(spath , '{}.pt'.format(na)))
    