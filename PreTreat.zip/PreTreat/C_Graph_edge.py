import numpy as np

def calculate_edges(coor):  # 输入各点坐标
    r=3  # 半径
    d = 32  # 一个节点的最大边数
    alpha = 1  # 调整时间和空间分辨率差异的比例因子
    beta = 1
    data_size = coor.shape[0]  # 事件点个数
    edges = np.zeros([100000, 2])  # 创建二维数组，10万行2列
    points = coor[:, 0:3]  # 提取所有坐标x,y,t
    row_num = 0 # 第几行
    edge_sum = 0  # 边总数
    for i in range(data_size - 1):  # 循环遍历除去最后一个事件的所有事件坐标
        count = 0
        distance_matrix = points[i + 1: data_size + 1, 0:3]  # 从points数组中提取出从第i+1到最后一个事件的所有坐标（x,y,t）。
        distance_matrix[:, 1:3] = distance_matrix[:, 1:3] - points[i, 1:3]  # 计算每个事件（从第i+1个开始）与当前事件（第i个）在x和y坐标上的差异。
        distance_matrix[:, 0] = distance_matrix[:, 0] - points[i, 0]  # 计算每个事件（从第i+1个开始）与当前事件（第i个）在时间t上的差异。
        distance_matrix = np.square(distance_matrix)  # 计算每个事件与当前事件在空间（x和y）和时间（t）上的差的平方。
        distance_matrix[:, 0] *= alpha  # 调整时间差（t）的权重，通过乘以alpha。
        distance_matrix[:, 1:3] *= beta  # 调整空间差（x和y）的权重，通过乘以beta。
        # 计算每对事件的距离
        distance = np.sqrt(np.sum(distance_matrix, axis=1))  # 计算每对事件之间的总距离（包括空间和时间的差异）。这是通过沿每行（axis=1）求和，然后取平方根得到的。
        index = np.where(distance <= r)  # 找出总距离小于或等于半径 r 的所有事件对的索引
        # 保存边
        if index:
            index = index[0].tolist()  # 如果index非空，将其转换为一个列表
            for id in index:  # 遍历index
                edges[row_num, 0] = i  # 在二维数组edges的第row_num行，第0列（即列索引为0的位置）赋值为i
                edges[row_num + 1, 1] = i  # 在二维数组edges的第row_num+1行，第1列（即列索引为1的位置）赋值为i
                edges[row_num, 1] = int(id) + i + 1  # 在二维数组edges的第row_num行，第1列（即列索引为1的位置）赋值为id+i+1，这里需要将id转为整数类型
                edges[row_num + 1, 0] = int(id) + i + 1  # 在二维数组edges的第row_num+1行，第0列（即列索引为0的位置）赋值为id+i+1，这里需要将id转为整数类型
                row_num = row_num + 2  # row_num增加2，即下一次循环时，将在新的两行中分别填充新的边信息
                count = count + 1  # 计数器count增加1，用于记录边的数量
                edge_sum += 2  # edge_sum增加2，表示边的总数，这里假设每次添加两条边
                if count > d:  # 如果边的数量大于d（可能是预先设定的最大边数阈值）
                    break
        if edge_sum > 40000:  # 如果边总数大于40000，跳出循环
            break
    edges = edges[~np.all(edges == 0, axis=1)]  # 过滤掉edges数组中所有在某一维度上全为0的行
    edges = np.transpose(edges)  # 转置edges数组，即将行和列互换
    return edges