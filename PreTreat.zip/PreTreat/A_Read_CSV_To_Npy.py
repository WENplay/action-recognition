import csv

def read_csv_to_npy(csv_path):
    # 初始化一个空的列表
    data = []

    # 打开你的csv文件
    with open(csv_path, 'r') as file:
        # 创建一个csv阅读器
        reader = csv.reader(file)
        # 遍历每一行
        for row in reader:
            # 创建一个列表，包含你需要的元素
            list = [row[1], row[0], row[4], row[3]]
            # 检查第四个元素是否不为0
            if list[3] != '0':
                # 如果第四个元素不为0，将这个列表添加到data中
                data.append(list)
    da=[[int(s) for s in sublist] for sublist in data]
    return da
